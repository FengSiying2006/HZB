"""
读取Excel文件，清洗数据，按客户汇总，按等比例拆分超大客户订单，
构建距离矩阵，并为各个节点分配初始物理属性。
"""
import pandas as pd
import numpy as np
from copy import deepcopy
import math
from config import (
    MAX_WEIGHT, MAX_VOLUME, SERVICE_TIME, START_EARLIEST,
    GREEN_ZONE_CENTER, GREEN_ZONE_RADIUS,
    RESTRICTED_END
)

def time_str_to_hour(t_str):
    """ 'HH:MM' -> 相对8:00的小时 """
    parts = t_str.strip().split(':')
    h, m = int(parts[0]), int(parts[1])
    return h + m/60.0 - START_EARLIEST

def load_and_preprocess(order_path, dist_path, coord_path, tw_path,
                        problem_id=1, save_cleaned_path=None):
    """
    problem_id: 1 = 无政策限制, 2 = 绿色配送区限行
    """
    # 1. 订单汇总
    df_order = pd.read_excel(order_path, sheet_name=0)
    df_order['重量'] = df_order['重量'].fillna(0)
    df_order['体积'] = df_order['体积'].fillna(0)
    demand_agg = df_order.groupby('目标客户编号').agg({'重量': 'sum', '体积': 'sum'})

    # 2. 距离矩阵
    df_dist = pd.read_excel(dist_path, sheet_name=0, index_col=0)
    df_dist.columns = [int(c) for c in df_dist.columns]
    df_dist.index = [int(i) for i in df_dist.index]
    dist_full = df_dist.values

    # 3. 时间窗
    df_tw = pd.read_excel(tw_path, sheet_name=0)
    tw_dict = {}
    for _, row in df_tw.iterrows():
        s = time_str_to_hour(row['开始时间'])
        e = time_str_to_hour(row['结束时间'])
        tw_dict[int(row['客户编号'])] = (s, e)
    tw_dict[0] = (0.0, 24.0)

    # 4. 坐标
    df_coord = pd.read_excel(coord_path, sheet_name=0)
    coord_dict = {int(row['ID']): (row['X (km)'], row['Y (km)']) for _, row in df_coord.iterrows()}

    # 5. 构建原始客户列表
    raw_customers = []
    for cid in range(1, 99):
        w = demand_agg.loc[cid, '重量'] if cid in demand_agg.index else 0
        v = demand_agg.loc[cid, '体积'] if cid in demand_agg.index else 0
        tw = tw_dict.get(cid, (0.0, 24.0))
        raw_customers.append({
            'original_id': cid,
            'x': coord_dict[cid][0], 'y': coord_dict[cid][1],
            'demand_weight': w, 'demand_volume': v,
            'ready_time': tw[0], 'due_time': tw[1],
            'service_time': SERVICE_TIME
        })

    # 6. 等比例拆分超大客户
    customers = []
    for cust in raw_customers:
        w, v = cust['demand_weight'], cust['demand_volume']

        # 避免空包裹或者除数为0的异常情况
        if w <= 1e-6 and v <= 1e-6:
            continue

        # 计算拆分份数，保证拆出来的货物物理密度一致
        k_w = math.ceil(w / MAX_WEIGHT) if MAX_WEIGHT > 0 else 1
        k_v = math.ceil(v / MAX_VOLUME) if MAX_VOLUME > 0 else 1
        k = max(1, k_w, k_v)

        for i in range(k):
            new_cust = deepcopy(cust)
            new_cust['demand_weight'] = w / k
            new_cust['demand_volume'] = v / k
            new_cust['id'] = f"{cust['original_id']}_{i+1}"
            customers.append(new_cust)

    # 7. 分配整数 node_id，扩展距离矩阵
    N = len(customers) + 1
    dist_matrix = np.zeros((N, N))
    id_map = {0: 0}
    for idx, c in enumerate(customers, start=1):
        c['node_id'] = idx
        original = int(c['id'].split('_')[0]) if '_' in c['id'] else c['id']
        c['original_id'] = original
        id_map[idx] = original

    for i in range(N):
        for j in range(N):
            orig_i = id_map[i]
            orig_j = id_map[j]
            dist_matrix[i][j] = dist_full[orig_i][orig_j]

    # 构建最终客户列表，移除双重绿区时间窗限制
    final_customers = []
    for c in customers:
        # 坐标
        x, y = c['x'], c['y']

        # 绿色区判定 (仅作为布尔标记供 evaluator 使用)
        dist_to_center = math.hypot(x - GREEN_ZONE_CENTER[0], y - GREEN_ZONE_CENTER[1])
        is_green = dist_to_center <= GREEN_ZONE_RADIUS

        orig_ready = c['ready_time']
        orig_due = c['due_time']

        final_customers.append({
            'id': c['node_id'],
            'original_id': c['original_id'],
            'x': x, 'y': y,
            'demand_weight': c['demand_weight'],
            'demand_volume': c['demand_volume'],
            'ready_time': orig_ready,
            'due_time': orig_due,
            'service_time': c['service_time'],
            'is_green_zone': is_green
        })

    # 8. 可选保存清洗数据
    if save_cleaned_path is not None:
        data_for_export = []
        for c in final_customers:
            data_for_export.append({
                'node_id': c['id'],
                'original_id': c['original_id'],
                'x': c['x'],
                'y': c['y'],
                'demand_weight_kg': c['demand_weight'],
                'demand_volume_m3': c['demand_volume'],
                'ready_time_rel8': c['ready_time'],
                'due_time_rel8': c['due_time'],
                'service_time_h': c['service_time'],
                'is_green_zone': c['is_green_zone']
            })
        # 配送中心
        data_for_export.append({
            'node_id': 0,
            'original_id': 0,
            'x': coord_dict[0][0],
            'y': coord_dict[0][1],
            'demand_weight_kg': 0.0,
            'demand_volume_m3': 0.0,
            'ready_time_rel8': 0.0,
            'due_time_rel8': 24.0,
            'service_time_h': 0.0,
            'is_green_zone': False
        })
        df_export = pd.DataFrame(data_for_export)
        df_export = df_export.sort_values('node_id').reset_index(drop=True)
        df_export.to_excel(save_cleaned_path, index=False, sheet_name='cleaned_data')
        print(f"清洗后的数据已保存至：{save_cleaned_path}")

    return final_customers, dist_matrix