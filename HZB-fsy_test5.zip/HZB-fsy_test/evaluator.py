"""
评估单条路径及完整方案的成本，包含出发时间优化
新增功能：
- 启发式最优出发时间估计（用于插入决策）
- 燃油车限行精准物理等待判定
- 出发时间网格搜索 + 局部精化
- 车辆数量超限罚款计入总成本
"""
import numpy as np
from scipy.optimize import minimize_scalar
from config import WAIT_COST_PER_HOUR, TARDY_COST_PER_HOUR, VEHICLE_TYPES, RESTRICTED_END
from cost_calculator import calculate_trip

def heuristic_departure(route_custs, vtype, customers, dist):
    """
    快速估计一条路径的较优出发时间，用于插入决策。
    原则：让车辆尽可能晚出发，但又能避免迟到，并减少经过不同速度时段的偏差。
    """
    if not route_custs:
        return 0.0
    avg_speed = 35.0   # 近似整体平均速度，误差比固定0.0小得多
    best_dep = 0.0
    cumul_dist = 0.0
    prev = 0

    for cust_id in route_custs:
        cumul_dist += dist[prev][cust_id]
        prev = cust_id
        cust = customers[cust_id-1]
        ready_time = cust['ready_time']

        # 预估到达时间
        est_arrival = best_dep + cumul_dist / avg_speed

        # 如果燃油车去绿区且预估到达在限行期内，需推迟出发时间
        if vtype.fuel_type == 'fuel' and cust.get('is_green_zone', False):
            if est_arrival < RESTRICTED_END:
                best_dep = max(best_dep, RESTRICTED_END - cumul_dist / avg_speed)
                est_arrival = best_dep + cumul_dist / avg_speed

        if est_arrival < ready_time:
            best_dep = max(best_dep, ready_time - cumul_dist / avg_speed)

    return max(0.0, best_dep)

def evaluate_route(route_custs, vtype, depart_time, customers, dist):
    """
    评估单条路径（不含始末0点），返回 (total_cost, detail_dict)
    修复：统合时间窗判定，修正绿区限行的物理等待逻辑
    """
    seq = [0] + route_custs + [0]
    t = depart_time
    cost = vtype.start_cost
    energy_cost = 0.0
    carbon_cost = 0.0
    penalty_cost = 0.0

    load = sum(customers[c-1]['demand_weight'] for c in route_custs)

    timeline = []

    for i in range(len(seq)-1):
        cur = seq[i]
        nxt = seq[i+1]
        load_ratio = load / vtype.cap_weight if vtype.cap_weight > 0 else 0

        # 调用 cost_calculator 中的物理计算
        trip = calculate_trip(cur, nxt, t, vtype, load_ratio, dist)
        energy_cost += trip['energy_cost']
        carbon_cost += trip['carbon_cost']
        t = trip['arrive_time'] # 更新为到达下一个节点的时刻

        if nxt != 0:
            cust = customers[nxt-1]
            ready, due = cust['ready_time'], cust['due_time']

            # 【核心修复】燃油车绿区精准判定
            if vtype.fuel_type == 'fuel' and cust.get('is_green_zone', False):
                if t < RESTRICTED_END:
                    # 车辆必须在绿区外等待，直到限行结束
                    t = RESTRICTED_END

            arr = t
            if t < ready:
                wait = ready - t
                penalty_cost += wait * WAIT_COST_PER_HOUR
                t = ready + cust['service_time']
                timeline.append((nxt, arr, ready))
            elif t > due:
                tardiness = t - due
                penalty_cost += tardiness * TARDY_COST_PER_HOUR
                t = t + cust['service_time']
                timeline.append((nxt, arr, t - cust['service_time']))
            else:
                t = t + cust['service_time']
                timeline.append((nxt, arr, t - cust['service_time']))

            load -= cust['demand_weight']
        else:
            # 回到起点
            timeline.append((0, t, t))

    # 极端解惩罚保护：如果惩罚成本高得离谱，直接丢弃（帮助 ALNS 过滤垃圾解）
    if penalty_cost > 1e6:
        return float('inf'), None

    total = cost + energy_cost + carbon_cost + penalty_cost
    return total, {
        'start_cost': cost,
        'energy_cost': energy_cost,
        'carbon_cost': carbon_cost,
        'penalty_cost': penalty_cost,
        'timeline': timeline,
        'departure_time': depart_time
    }

def optimize_departure_time(route_custs, vtype, customers, dist):
    """ 网格搜索 + 局部精化寻找最优出发时间 """
    def f(dep):
        c, _ = evaluate_route(route_custs, vtype, dep, customers, dist)
        return c if c < float('inf') else 1e12

    # 粗网格搜索，步长 0.5 小时
    best_dep = 0.0
    best_val = float('inf')
    for x in np.arange(0.0, 10.0 + 0.5, 0.5):
        val = f(x)
        if val < best_val:
            best_val = val
            best_dep = x

    # 局部精化，区间宽度 2 小时
    lb = max(0.0, best_dep - 1.0)
    ub = min(10.0, best_dep + 1.0)
    res = minimize_scalar(f, bounds=(lb, ub), method='bounded')

    best_cost, details = evaluate_route(route_custs, vtype, res.x, customers, dist)
    if details is not None:
        details['departure_time'] = res.x
    return best_cost, res.x, details


def evaluate_solution(routes, customers, dist):
    total = 0.0
    route_details = []
    type_count = {vtype.id: 0 for vtype in VEHICLE_TYPES}

    # === 新增：全覆盖与防重复校验 ===
    served_customers = set()
    all_customers = set(c['id'] for c in customers)

    for r in routes:
        vtype = r['vtype']
        type_count[vtype.id] += 1
        custs = r['customers']

        # 记录并检查被服务的客户
        for c_id in custs:
            if c_id in served_customers:
                # 发现重复服务（一人多送），判为无效解
                return float('inf'), None
            served_customers.add(c_id)

        w = sum(customers[c - 1]['demand_weight'] for c in custs)
        v = sum(customers[c - 1]['demand_volume'] for c in custs)
        # 容量防抖：增加 1e-5 的浮点容差
        if w > vtype.cap_weight + 1e-5 or v > vtype.cap_volume + 1e-5:
            return float('inf'), None

    # === 新增：漏送拦截 ===
    if served_customers != all_customers:
        # 发现漏送节点，直接判为死解
        missing_count = len(all_customers - served_customers)
        # 可选：如果你想在控制台看到警告，可以取消下面这行的注释
        # print(f"警告：评估器拦截了一个无效解，漏送了 {missing_count} 个客户！")
        return float('inf'), None

    # 车辆数量超限罚款
    penalty_excess = 0.0
    for vtype in VEHICLE_TYPES:
        if type_count[vtype.id] > vtype.count:
            excess = type_count[vtype.id] - vtype.count
            penalty_excess += excess * 100000.0

    for r in routes:
        vtype = r['vtype']
        custs = r['customers']
        cost, dep, det = optimize_departure_time(custs, vtype, customers, dist)

        if det is None:
            return float('inf'), None

        total += cost
        det['vtype_name'] = vtype.name
        det['vtype'] = vtype
        det['customers'] = custs
        route_details.append(det)

    total += penalty_excess  # 计入罚款
    return total, route_details