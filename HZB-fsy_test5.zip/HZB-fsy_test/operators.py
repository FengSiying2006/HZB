"""
ALNS 使用的破坏（removal）与修复（insertion）算子
包含修复后的全局贪心算子和安全的 Regret-2 算子。
"""
import random
from evaluator import evaluate_route, heuristic_departure
from config import VEHICLE_TYPES, RESTRICTED_END

def _can_serve(vtype, cust):
    """
    检查某车型能否服务给定客户的先决条件
    逻辑：如果燃油车去绿区，且客户的最晚接受时间都在限行结束之前，则判定为不可服务。
    """
    if vtype.fuel_type == 'fuel' and cust.get('is_green_zone', False):
        if cust['due_time'] < RESTRICTED_END:
            return False
    return True

# ==================== 破坏算子 (Removal Operators) ====================

def random_removal(routes, num_remove):
    """ 随机移除客户：增加搜索多样性 """
    all_custs = [(ri, ci, c) for ri, r in enumerate(routes) for ci, c in enumerate(r['customers'])]
    if not all_custs:
        return routes, []

    num = min(num_remove, len(all_custs))
    chosen = random.sample(all_custs, num)

    # 逆序删除，防止索引偏移
    for ri, ci, _ in sorted(chosen, key=lambda x: (x[0], x[1]), reverse=True):
        del routes[ri]['customers'][ci]

    removed = [c for _, _, c in chosen]
    routes = [r for r in routes if len(r['customers']) > 0]
    return routes, removed


def worst_removal(routes, num_remove, customers, dist):
    """ 移除使得路径成本降低最大的客户（节约原则） """
    savings = []
    for ri, r in enumerate(routes):
        vtype = r['vtype']
        for ci, c in enumerate(r['customers']):
            route_without = r['customers'][:ci] + r['customers'][ci+1:]

            dep_before = heuristic_departure(r['customers'], vtype, customers, dist)
            cost_before, _ = evaluate_route(r['customers'], vtype, dep_before, customers, dist)

            if not route_without:
                savings.append((ri, ci, c, cost_before - vtype.start_cost))
            else:
                dep_after = heuristic_departure(route_without, vtype, customers, dist)
                cost_after, _ = evaluate_route(route_without, vtype, dep_after, customers, dist)
                savings.append((ri, ci, c, cost_before - cost_after))

    savings.sort(key=lambda x: x[3], reverse=True)

    remove_set = set()
    removed = []
    to_delete = []
    for ri, ci, c, _ in savings:
        if len(removed) >= num_remove: break
        if c not in remove_set:
            remove_set.add(c)
            removed.append(c)
            to_delete.append((ri, ci))

    # 逆序按路线分组删除，防止索引错乱
    for ri, ci in sorted(to_delete, key=lambda x: (x[0], x[1]), reverse=True):
        del routes[ri]['customers'][ci]

    routes = [r for r in routes if len(r['customers']) > 0]
    return routes, removed


# ==================== 修复算子 (Insertion Operators) ====================

def greedy_insert(routes, removed_custs, customers, dist):
    """ 修复后的全局贪心插入法 """
    type_count = {vtype.id: 0 for vtype in VEHICLE_TYPES}
    for r in routes:
        type_count[r['vtype'].id] += 1

    while removed_custs:
        global_best_delta = float('inf')
        global_best_dest = None
        global_best_cust = None

        for c in removed_custs:
            cust = customers[c-1]
            best_delta_for_c = float('inf')
            best_dest_for_c = None

            # 1. 尝试插入现有路径
            for ri, r in enumerate(routes):
                vtype = r['vtype']
                if not _can_serve(vtype, cust): continue

                for pos in range(len(r['customers']) + 1):
                    new_route = r['customers'][:pos] + [c] + r['customers'][pos:]

                    w = sum(customers[x-1]['demand_weight'] for x in new_route)
                    vol = sum(customers[x-1]['demand_volume'] for x in new_route)
                    if w > vtype.cap_weight + 1e-6 or vol > vtype.cap_volume + 1e-6:
                        continue

                    dep_before = heuristic_departure(r['customers'], vtype, customers, dist) if r['customers'] else 0.0
                    cost_before = evaluate_route(r['customers'], vtype, dep_before, customers, dist)[0] if r['customers'] else 0

                    dep_after = heuristic_departure(new_route, vtype, customers, dist)
                    cost_after = evaluate_route(new_route, vtype, dep_after, customers, dist)[0]

                    delta = cost_after - (cost_before if r['customers'] else vtype.start_cost)

                    if delta < best_delta_for_c:
                        best_delta_for_c = delta
                        best_dest_for_c = ('existing', ri, pos)

            # 2. 尝试新建路径
            for tid, vtype in enumerate(VEHICLE_TYPES):
                if not _can_serve(vtype, cust): continue
                if type_count.get(vtype.id, 0) >= vtype.count: continue
                if cust['demand_weight'] > vtype.cap_weight + 1e-6 or cust['demand_volume'] > vtype.cap_volume + 1e-6: continue

                new_route = [c]
                dep_new = heuristic_departure(new_route, vtype, customers, dist)
                cost_new = evaluate_route(new_route, vtype, dep_new, customers, dist)[0]

                if cost_new < best_delta_for_c:
                    best_delta_for_c = cost_new
                    best_dest_for_c = ('new', tid)

            if best_delta_for_c < global_best_delta and best_dest_for_c is not None:
                global_best_delta = best_delta_for_c
                global_best_dest = best_dest_for_c
                global_best_cust = c

        if global_best_cust is not None:
            removed_custs.remove(global_best_cust)
            if global_best_dest[0] == 'new':
                vtype = VEHICLE_TYPES[global_best_dest[1]]
                routes.append({'vtype': vtype, 'customers': [global_best_cust]})
                type_count[vtype.id] += 1
            else:
                ri, pos = global_best_dest[1], global_best_dest[2]
                routes[ri]['customers'].insert(pos, global_best_cust)
        else:
            # 异常兜底保护，防止死循环
            break

    return routes


def regret2_insert(routes, removed_custs, customers, dist):
    """ 修复数值崩溃的 Regret-2 插入法 """
    type_count = {vtype.id: 0 for vtype in VEHICLE_TYPES}
    for r in routes:
        type_count[r['vtype'].id] += 1

    while removed_custs:
        regrets = []
        for c in removed_custs:
            best_vals = []
            cust = customers[c-1]

            # 1. 现有路径评估
            for ri, r in enumerate(routes):
                vtype = r['vtype']
                if not _can_serve(vtype, cust): continue

                for pos in range(len(r['customers']) + 1):
                    new_route = r['customers'][:pos] + [c] + r['customers'][pos:]

                    w = sum(customers[x-1]['demand_weight'] for x in new_route)
                    vol = sum(customers[x-1]['demand_volume'] for x in new_route)
                    if w > vtype.cap_weight + 1e-6 or vol > vtype.cap_volume + 1e-6:
                        continue

                    dep_after = heuristic_departure(new_route, vtype, customers, dist)
                    cost_after = evaluate_route(new_route, vtype, dep_after, customers, dist)[0]

                    dep_before = heuristic_departure(r['customers'], vtype, customers, dist) if r['customers'] else 0.0
                    cost_before = evaluate_route(r['customers'], vtype, dep_before, customers, dist)[0] if r['customers'] else vtype.start_cost

                    delta = cost_after - cost_before
                    best_vals.append((delta, ('existing', ri, pos)))

            # 2. 新建路径评估
            for tid, vtype in enumerate(VEHICLE_TYPES):
                if not _can_serve(vtype, cust): continue
                if type_count.get(vtype.id, 0) >= vtype.count: continue
                if cust['demand_weight'] > vtype.cap_weight + 1e-6 or cust['demand_volume'] > vtype.cap_volume + 1e-6: continue

                new_route = [c]
                dep_new = heuristic_departure(new_route, vtype, customers, dist)
                cost_new = evaluate_route(new_route, vtype, dep_new, customers, dist)[0]
                best_vals.append((cost_new, ('new', tid)))

            # 3. 计算后悔值，过滤 inf 异常
            best_vals.sort(key=lambda x: x[0])
            valid_vals = [v for v in best_vals if v[0] != float('inf')]

            if len(valid_vals) >= 2:
                regret = valid_vals[1][0] - valid_vals[0][0]
            elif len(valid_vals) == 1:
                regret = 1e6 # 只有一个可行解，必须抢占
            else:
                continue # 彻底无法插入，忽略

            if valid_vals:
                regrets.append((c, valid_vals[0][1], regret))

        if not regrets:
            break

        # 选择后悔值最大的客户进行插入
        regrets.sort(key=lambda x: x[2], reverse=True)
        c, dest, _ = regrets[0]
        removed_custs.remove(c)

        if dest[0] == 'new':
            vtype = VEHICLE_TYPES[dest[1]]
            routes.append({'vtype': vtype, 'customers': [c]})
            type_count[vtype.id] += 1
        else:
            ri, pos = dest[1], dest[2]
            routes[ri]['customers'].insert(pos, c)

    return routes